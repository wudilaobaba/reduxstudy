import {combineReducers} from "redux-immutable";
import { reducer as headerReducer } from "../components/Header/store"
import { reducer as homeReducer } from "../pages/Index/store"
const reducer = combineReducers({
  header: headerReducer,
  index: homeReducer
});
export default reducer;