import React from "react"
const Detail = (props)=>{
    return(
        <>
            <h1>详情页</h1>
        </>
    )
};
export default Detail;