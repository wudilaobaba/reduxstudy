import React from "react"
import Topic from "./components/Topic";
import List from "./components/List";
const Index = (props)=>{
    return(
        <>
            <h1>首页</h1>
            <Topic/>
            <List/>
        </>
    )
};
export default Index;