import React from "react"
import { connect } from 'react-redux'
import {actionCreators} from "../store";
const Topic = (props)=>{
    const {topicList} = props;
    return(
        <>
            <h1>Topic</h1>
            <ul>
                {renderList(topicList.toJS())}
            </ul>
        </>
    )
};

const renderList = (list)=>{
    return list.map((item)=>{
        return <li key={item.id}>{item.title}</li>
    })
};

const mapStateToProps = (state) => { //参数state是store中的数据，将state映射到组件的props里面
    return {
        topicList: state.getIn(["index", "topicList"]),
    }
};

//将store.dispatch方法挂载到props上
const mapDispatchToProps = (dispatch) => { //修改数据的方法, 参数dispatch就是store.dispatch
    return {
        changeFocused() {
            dispatch(actionCreators.changeFocused())
        },
        ajax(){
            dispatch(actionCreators.ajax())
        }
    }
};
export default connect(mapStateToProps, mapDispatchToProps)(Topic)