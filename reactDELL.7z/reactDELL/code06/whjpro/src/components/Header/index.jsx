import React from "react"
import {HeaderWrapper, Logo, Button} from "./style"
import { connect } from 'react-redux'
import { actionCreators } from "./store"

const Header = (props)=>{
  const {changeFocused, ajax, list, focused} = props;
  return(
      <>
          <HeaderWrapper>
            <Logo href={"http://www.baidu.com"}/>
            <Button onClick={changeFocused}>测试Header中数据 --> {focused + ""}</Button>
              <br/>
              <Button onClick={ajax}>发送AJAX</Button>
              {
                  renderList(list)
              }
          </HeaderWrapper>
      </>
  )
};
const renderList = (list)=>{
    return list.toJS().map((item)=>{
        return <div key={item.age}>{item.name}</div>
    })
};
const mapStateToProps = (state) => { //参数state是store中的数据，将state映射到组件的props里面
    return {
        list:state.getIn(["header", "list"]),
        focused:state.getIn(["header", "focused"]),
        // focused:state.get("header").get("focused"),
    }
};

//将store.dispatch方法挂载到props上
const mapDispatchToProps = (dispatch) => { //修改数据的方法, 参数dispatch就是store.dispatch
    return {
        changeFocused() {
            dispatch(actionCreators.changeFocused())
        },
        ajax(){
            dispatch(actionCreators.ajax())
        }
    }
};
export default connect(mapStateToProps, mapDispatchToProps)(Header)