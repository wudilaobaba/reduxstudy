import styled from "styled-components";
import logoPic from "../../statics/w.png"
export const HeaderWrapper = styled.div`
    height:300px;
    background:red;
`;

export const Logo = styled.a`
    display:block;
    width:100px;
    height:58px;
    background:url(${logoPic});
`;
export const Button = styled.button`
    
`;