import { Provider } from 'react-redux'
import store from './store'
import {GlobalStyle} from './style.js';
import React from "react";
import {BrowserRouter,Route} from 'react-router-dom'
import Header from './components/Header'
import Index from './pages/Index'
import Detail from './pages/Detail'


function App() {
  return (
      <Provider store={store}>
          <div>
              <GlobalStyle/>
              <Header/>
              <BrowserRouter>
                  <div>
                      <Route exact path="/" component={Index}></Route>
                      <Route exact path="/detail" component={Detail}></Route>
                  </div>
              </BrowserRouter>
          </div>
      </Provider>
  );
}

export default App;
