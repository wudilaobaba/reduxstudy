import {CHANGE_INPUT_VALUE, SUBMIT_VALUE, DEL_ITEM,INIT_DATA } from "./actionTypes"
export const getInputChangeAction = (value) => ({
    type: CHANGE_INPUT_VALUE,
    value
});
export const delAction = (value) => ({
    type: DEL_ITEM,
    value
});
export const submitAction = () => ({
    type: SUBMIT_VALUE
});


// 接受AJAX的数据
export const initListDatasAction = (value)=>({
    type: INIT_DATA,
    value
});