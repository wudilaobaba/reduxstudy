export const CHANGE_INPUT_VALUE = "change_input_value";
export const SUBMIT_VALUE = "subMit_value";
export const DEL_ITEM = "del_item";
export const INIT_DATA = "init_data";