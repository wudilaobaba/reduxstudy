import {CHANGE_INPUT_VALUE, SUBMIT_VALUE, DEL_ITEM,INIT_DATA } from "./actionTypes"
const defaultState = {
  inputValue: '',
  listData: []
};

//reducer可以接收state但是绝对不能修改state
export default (state = defaultState, action) => {
  //参数state就是笔记本上的所有书籍的数据，也就是整个store的数据，默认笔记本上有inputValue和listDate两条数据
  //参数action就是store.dispatch({value:1,listData:[1,2,3]})中的参数，是一个对象
  //一旦store.dispatch(action)的时候，就会执行这里的逻辑
  console.log(state, action);
  if (action.type === CHANGE_INPUT_VALUE) {
    //先深度拷贝state
    const newState = JSON.parse(JSON.stringify(state));
    newState.inputValue = action.value;
    return newState //将新的数据返回给了store，并替换掉老的数据，此时inputValue的值已经修改了
  }
  if(action.type === SUBMIT_VALUE){
    const newState = JSON.parse(JSON.stringify(state));
    newState.listData.push({id:new Date(),value:newState.inputValue });
    newState.inputValue = "";
    return newState
  }
  if(action.type === DEL_ITEM){
    const newState = JSON.parse(JSON.stringify(state));
    let arr = newState.listData.filter((item)=>item.id!==action.value);
    newState.listData = arr;
    return newState
  }
  if(action.type === INIT_DATA){
    const newState = JSON.parse(JSON.stringify(state));
    newState.listData = action.value;
    return newState
  }
  return state
}