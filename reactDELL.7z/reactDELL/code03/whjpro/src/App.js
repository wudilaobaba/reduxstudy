import { Provider } from 'react-redux'
import store from './store'
import TodoList from "./pages/TotoList";
function App() {
  return (
      <Provider store={store}>
          <TodoList/>
      </Provider>
  );
}

export default App;
