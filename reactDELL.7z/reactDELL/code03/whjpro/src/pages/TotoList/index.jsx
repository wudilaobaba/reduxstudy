import React from "react"
import { connect } from 'react-redux'
import { getInputChangeAction, submitAction, delAction } from "../../store/actionCreators"

const TodoList = (props)=>{
    const {inputValue, listData, changeInputVal, submit, del} = props;
    const renderList = ()=>{
        return listData.map((item)=>{
            return <li key={item.id} onClick={()=>{del(item.id)}}>{item.value}</li>
        })
    };

    return (
        <>
            <input value={inputValue} onChange={changeInputVal}/>
            <button onClick={submit}>提交</button>
            <ul>
                {renderList()}
            </ul>
        </>
    )
};

const mapStateToProps = (state) => { //参数state是store中的数据，将state映射到组件的props里面
    return {
        inputValue: state.inputValue, //将state.inputValue映射到组件的props的inputValue里面
        listData: state.listData
    }
};

//将store.dispatch方法挂载到props上
const mapDispatchToProps = (dispatch) => { //修改数据的方法, 参数dispatch就是store.dispatch
    return {
        changeInputVal(e) {
            const action = getInputChangeAction(e.target.value);
            dispatch(action)
        },
        submit(){
            dispatch(submitAction());
        },
        del(id){
            dispatch(delAction(id))
        }
    }
};
export default connect(mapStateToProps, mapDispatchToProps)(TodoList)