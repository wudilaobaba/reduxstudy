import React from "react"
import Header from "../../components/Header"
const Index = (props)=>{
    return(
        <>
            <Header/>
        </>
    )
};
export default Index;