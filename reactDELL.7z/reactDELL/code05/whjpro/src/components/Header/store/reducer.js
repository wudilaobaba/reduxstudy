import * as constants from "./constants"
import { fromJS } from "immutable";
// 感觉fromJS就是一个把json对象返回为Map的方法
// let a = fromJS({ "a":1 });
// a.set( "a" , 2 ); 返回一个全新的对象

const defaultState = fromJS({
    focused: false,
    list: []
});

//reducer可以接收state但是绝对不能修改state
export default (state = defaultState, action) => {
    console.log(state, action);
    switch (action.type) {
        case constants.CHANGE_FOCUSED:
            return state.set("focused",!state.get("focused"));//这是一个全新的对象
        case constants.RENDER_LIST:
            //一次设置多个store数据
            return state.merge({
                list:action.value,
                focused:!state.get("focused")
            });
        default:
            return state
    }
}