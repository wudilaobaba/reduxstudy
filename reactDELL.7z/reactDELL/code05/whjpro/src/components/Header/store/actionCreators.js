import * as constants from "./constants"
import { fromJS } from "immutable";
export const changeFocused = () => ({
    type: constants.CHANGE_FOCUSED,
});
const renderList = (value) => ({
    type: constants.RENDER_LIST,
    value: fromJS(value)
});

export const ajax = () => {
    return (dispatch)=>{
        setTimeout(()=>{
            let data = [
                {age:1,name:"Mike"},
                {age:2,name:"Tom"},
                {age:3,name:"Kite"},
            ];
            dispatch(renderList(data));
        },2000)
    }
};