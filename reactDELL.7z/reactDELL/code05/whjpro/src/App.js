import { Provider } from 'react-redux'
import store from './store'
import {GlobalStyle} from './style.js';
import Index from "./pages/Index"
import React from "react";
function App() {
  return (
      <Provider store={store}>
          <GlobalStyle/>
          <Index/>
      </Provider>
  );
}

export default App;
