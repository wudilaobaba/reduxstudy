import React from "react"
import {HeaderWrapper, Logo, Button} from "./style"
import { connect } from 'react-redux'
import { actionCreators } from "./store"

const Header = (props)=>{
  return(
      <>
          <HeaderWrapper>
            <Logo href={"http://www.baidu.com"}/>
            <Button onClick={props.changeFocused}>测试Header中数据 --> {props.focused + ""}</Button>
          </HeaderWrapper>
      </>
  )
};
const mapStateToProps = (state) => { //参数state是store中的数据，将state映射到组件的props里面
    return {
        focused:state.header.focused,
    }
};

//将store.dispatch方法挂载到props上
const mapDispatchToProps = (dispatch) => { //修改数据的方法, 参数dispatch就是store.dispatch
    return {
        changeFocused() {
            dispatch(actionCreators.changeFocused())
        },
    }
};
export default connect(mapStateToProps, mapDispatchToProps)(Header)