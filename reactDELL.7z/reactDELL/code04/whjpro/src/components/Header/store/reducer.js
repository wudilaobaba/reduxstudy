import * as constants from "./constants"
const defaultState = {
    focused: false,
};

//reducer可以接收state但是绝对不能修改state
export default (state = defaultState, action) => {
    console.log(state, action);
    if (action.type === constants.CHANGE_FOCUSED) {
        //先深度拷贝state
        const newState = JSON.parse(JSON.stringify(state));
        newState.focused = !newState.focused;
        return newState //将新的数据返回给了store，并替换掉老的数据，此时inputValue的值已经修改了
    }
    return state
}