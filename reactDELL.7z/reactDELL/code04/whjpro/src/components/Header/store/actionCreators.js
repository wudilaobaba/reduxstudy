import * as constants from "./constants"
export const changeFocused = () => ({
    type: constants.CHANGE_FOCUSED,
});