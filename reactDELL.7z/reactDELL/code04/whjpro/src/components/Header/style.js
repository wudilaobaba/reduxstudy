import styled from "styled-components";
import logoPic from "../../statics/w.png"
export const HeaderWrapper = styled.div`
    height:58px;
    background:red;
    position:relative;
`;

export const Logo = styled.a`
    display:block;
    position:absolute;
    top:0;
    left:0;
    width:100px;
    height:58px;
    background:url(${logoPic});
`;
export const Button = styled.button`
    position:absolute;
    top:0;
    left:500px;
`;