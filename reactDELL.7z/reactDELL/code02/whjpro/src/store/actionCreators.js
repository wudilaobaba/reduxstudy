import {CHANGE_INPUT_VALUE, SUBMIT_VALUE, DEL_ITEM,INIT_DATA } from "./actionTypes"
export const getInputChangeAction = (value) => ({
    type: CHANGE_INPUT_VALUE,
    value
});
export const delAction = (value) => ({
    type: DEL_ITEM,
    value
});
export const submitAction = () => ({
    type: SUBMIT_VALUE
});


// 接受AJAX的数据
export const initListDatasAction = (value)=>({
    type: INIT_DATA,
    value
});


export const getTotoListDatas = ()=>{
  return (dispatch)=>{
      setTimeout(()=>{
          let data = [
              {id:123,value:"eee"},
              {id:222,value:"qqq"},
              {id:333,value:"rrr"},
              {id:444,value:"111"}
          ];
          console.log(data);
          dispatch(initListDatasAction(data));
      },2000)
  }
};