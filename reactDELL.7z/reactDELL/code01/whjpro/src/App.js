import TodoList from "./pages/TotoList";
function App() {
  return (
    <div>
      <TodoList/>
    </div>
  );
}

export default App;
