import React,{useEffect ,useState} from "react"
import store from "../../store";
import {getInputChangeAction, submitAction, delAction,initListDatasAction} from "../../store/actionCreators"
const TodoList = ()=>{
  const [datas, setDatas] = useState(store.getState);
  useEffect(()=>{
      store.subscribe(storeChange);//只要store中的数据发生变化，就执行storeChange方法


      //使用redux发送AJAX
      setTimeout(()=>{
          let data = [
              {id:123,value:"eee"},
              {id:222,value:"qqq"},
              {id:333,value:"rrr"},
              {id:444,value:"111"}
          ];
          store.dispatch(initListDatasAction(data));
      },2000)

  },[]);

  const renderList = ()=>{
    return datas.listData.map((item,index)=>{
        return <li key={item.id} onClick={()=>{del(item.id)}}>{item.value}</li>
    })
  };

  const del = (id)=>{
      store.dispatch(delAction(id));
  };

  const storeChange = ()=>{
      setDatas(store.getState);
  };

  const changeInputVal = (e)=>{
      store.dispatch(getInputChangeAction(e.target.value));
  };

  const subMit = ()=>{
      store.dispatch(submitAction());
  };

  return(
      <>
        <input
            value={datas.inputValue}
            onChange={changeInputVal}
        />
        <button onClick={subMit}>OK</button>
          {renderList()}
      </>
  )
};
export default TodoList;