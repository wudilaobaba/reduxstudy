npm i -S redux               code01
npm i -S redux-thunk         code02
npm i -S react-redux redux   code03
npm i -S styled-components   code04以及组件redux的拆分
npm i -S immutable redux-immutable redux-thunk           code05 基于code04
所有异步请求都在actionCreators.js中执行


code05中所有组件中的store属性值都是immutable类型，要使用.toJS()来转换成js对象


public下的api目录创建json文件，访问以下可以输出对应的json数据
    http://localhost:3000/api/mock.json


特大注意：特大注意：001
组件mapDispatchToProps中的方法不能直接使用mapStateToProps中的这些个数据，如果一定要使用，那么：
假设：
changeListData是mapDispatchToProps中的一个方法
page是mapStateToProps中的一个数据
changeListData想使用page数据就要在组件上通过箭头函数的形式将page数据传过来使用(必须要用箭头函数！！！)：
<SearchInfoSwitch onClick={()=>{changeListData(page)}}>



code06路由
  npm i -S react-router-dom
  页面组件中的样式公用页面index的
  页面组件中的小组件使用页面的redux数据，小组件要引入connect


